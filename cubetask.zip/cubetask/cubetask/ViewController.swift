//
//  ViewController.swift
//  cubetask
//
//  Created by Ritesh Chowdary on 6/15/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var count: UILabel!
    var countTrack = 0
    var flag = false
    var staStop = true
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    


    @IBAction func btnStart(_ sender: UIButton) {
        if(staStop){
            staStop = false
        }
        else{
        staStop = true
        }
        fordown()
        //if(self.imageView.frame.origin.y == 700){
        //backtop()
       // }
    }
    func fordown(){
        UIView.animate(withDuration: 1, delay: 0, animations: {
        self.imageView.frame.origin.x += 290}){
            _ in UIView.animateKeyframes(withDuration: 1, delay: 1, animations: {
                
                self.imageView.frame.origin.y += 700;
                self.backtop()
                //self.countTrack += 1
                //self.count.text = String(self.countTrack)
                //imageView.backgroundColor = UIColor(cgColor: <#T##CGColor#>)

            })
               //self.backtop()
            }

    }
    
    func backtop(){
        UIView.animate(withDuration: 1, delay: 2, animations: {
        self.imageView.frame.origin.x -= 290}){
        _ in UIView.animateKeyframes(withDuration: 1, delay: 1, animations: {
                
            self.imageView.frame.origin.y -= 700;
            
            //self.countTrack += 1
            //self.count.text = String(self.countTrack)
        })

    }
    
}
}

